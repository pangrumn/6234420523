package lab10_1;
public class Secretary extends Employee implements Evaluation{
    private int typingSpeed;
    private int[] score;
    public Secretary(String name,int salary, int[] score,int typingSpeed){
        super(name,salary);
        this.score=score;
        this.typingSpeed=typingSpeed;
    }
    public double evaluate(){
        int sum=0;
        for(int i=0;i<score.length;i++){
            sum+=score[i];
        }
        return sum;
    }
    public char grade(double evaluate){
        if(evaluate>=90){
            super.setSalary(18000);
            return 'P';
        }
        return 'F';
    }
}
