package lab10_1;
public class Subject implements Evaluation{
    private String subjName;
    private int[] score;
    public Subject(String subjName,int[] score){
        this.subjName=subjName;
        this.score=score;
    }
    public double evaluate(){
        double sum=0;
        for(int i=0;i<score.length;i++){
            sum+=score[i];
        }
        sum=sum/score.length;
        return sum;
    }
    public char grade(double evaluate){
        if(evaluate>=70){
            return 'P';
        }
        return 'F';
    }
    public String toString(){
        return subjName;
    }
}
