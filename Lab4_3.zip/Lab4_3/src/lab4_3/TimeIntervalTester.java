/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4_3;

import java.util.Scanner;

/**
 *
 * @author nutnichaboonrod
 */
public class TimeIntervalTester {
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter start time: ");
        int start1 = sc.nextInt();
        System.out.print("Enter end time: ");
        int end1 = sc.nextInt();
        TimeInterval timeTester = new TimeInterval(start1,end1);
        System.out.println(timeTester.getHours()+" hours "+timeTester.getMinutes()+" minutes\n");
    }
    
}
