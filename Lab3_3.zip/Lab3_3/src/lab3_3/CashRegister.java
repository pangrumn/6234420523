/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3_3;

/**
 *
 * @author nutnichaboonrod
 */
public class CashRegister {
private double purchase;
    private double payment;
    private double taxPurchase;
    private final double taxRate;
    private double total;
    public CashRegister (double taxRate){
        this.taxRate=taxRate/100.00;
    }
    public void recordPurchase (double purchase){
        this.purchase=this.purchase+purchase;
    }
    public void enterPayment (double payment){
        this.payment=this.payment+payment;
    }
    public void recordTaxablePurchase (double taxPurchase){
        this.taxPurchase=taxPurchase+(taxPurchase*this.taxRate);
        total=this.purchase+this.taxPurchase;
    }
    public double getTotalTax(){
        return total;
    }
    public float giveChange(){
        double change=payment-total;
        purchase=0;
        payment=0;
        return (float) change;
    }

}
