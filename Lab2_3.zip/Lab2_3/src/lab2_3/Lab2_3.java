/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab2_3;

import java.util.Calendar;
import java.util.GregorianCalendar;

/**
 *
 * @author nutnichaboonrod
 */
public class Lab2_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        GregorianCalendar cal = new GregorianCalendar();
        GregorianCalendar myBirthday = new GregorianCalendar(2001, Calendar.MARCH, 1);
        
        cal.add(Calendar.DAY_OF_MONTH, 100);
        myBirthday.add(Calendar.DAY_OF_MONTH, 10000);
        
        int dayweek1 = cal.get(Calendar.DAY_OF_WEEK);
        int daymonth1 = cal.get(Calendar.DAY_OF_MONTH);
        int month1 = cal.get(Calendar.MONTH) + 1 ;
        int year1 = cal.get(Calendar.YEAR);
        
        int dayweek2 = myBirthday.get(Calendar.DAY_OF_WEEK);
        int daymonth2 = myBirthday.get(Calendar.DAY_OF_MONTH);
        int month2 = myBirthday.get(Calendar.MONTH) + 1 ;
        int year2 = myBirthday.get(Calendar.YEAR);
        
        System.out.println(""+ dayweek1+ " "+ daymonth1+ " "+ month1+ " "+ year1);
        System.out.println(""+ dayweek2+ " "+ daymonth2+ " "+ month2+ " "+ year2);
    }
    
}
